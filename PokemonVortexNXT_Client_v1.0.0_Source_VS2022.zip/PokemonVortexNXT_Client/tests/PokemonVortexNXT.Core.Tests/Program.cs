using PokemonVortexNXT.Core;

var tests = new (string Name, Action Run)[]
{
    ("Canonical endpoint setup", CanonicalEndpoints),
    ("Invalid endpoint settings", InvalidEndpoints),
    ("Allowed game navigation", AllowedNavigation),
    ("Blocked navigation and ambiguous paths", BlockedNavigation),
    ("Home aliases and history boundary", HomeBoundary),
    ("Settings defaults and round trip", SettingsRoundTrip),
    ("Settings backup recovery", BackupRecovery),
    ("Settings corruption fallback and validation", CorruptionFallback),
    ("Browser profile isolation", ProfileIsolation)
};
int failures = 0;
foreach ((string name, Action run) in tests)
{
    try { run(); Console.WriteLine("PASS " + name); }
    catch (Exception exception) { failures++; Console.Error.WriteLine("FAIL " + name + ": " + exception.Message); }
}
Console.WriteLine($"{tests.Length - failures}/{tests.Length} groups passed.");
return failures == 0 ? 0 : 1;

static GameEndpoint Endpoint(string address)
{
    Check(GameEndpoint.TryCreate(address, out GameEndpoint? result, out string error), address + ": " + error);
    return result!;
}

static void Check(bool condition, string message)
{
    if (!condition) throw new InvalidOperationException(message);
}

static void Equal<T>(T expected, T actual)
    => Check(EqualityComparer<T>.Default.Equals(expected, actual), $"Expected [{expected}], got [{actual}].");

static void CanonicalEndpoints()
{
    Equal(GameEndpoint.DefaultAddress, Endpoint("http://127.0.0.1").HomeUri.AbsoluteUri);
    Equal(GameEndpoint.DefaultAddress, Endpoint("  http://127.0.0.1/  ").HomeUri.AbsoluteUri);
    Equal("https://example.com/PokemonVortex/", Endpoint("HTTPS://EXAMPLE.COM:443").HomeUri.AbsoluteUri);
    Equal("http://localhost:8080/CustomGame/", Endpoint("http://localhost:8080/CustomGame").HomeUri.AbsoluteUri);
    Equal("http://[::1]:8080/PokemonVortex/", Endpoint("http://[::1]:8080").HomeUri.AbsoluteUri);
    Equal("https://xn--bcher-kva.example/PokemonVortex/", Endpoint("https://bücher.example").HomeUri.AbsoluteUri);
    Equal("http://localhost/Pokemon%20Vortex/", Endpoint("http://localhost/Pokemon%20Vortex/").HomeUri.AbsoluteUri);
}

static void InvalidEndpoints()
{
    string[] invalid = ["", "example.com", "//example.com/", "file:///C:/game/", "javascript:alert(1)",
        "ftp://example.com/game/", "http:///game/", "http://user:pass@example.com/game/",
        "http://@example.com/game/", "http://example.com/PokemonVortex/?a=1", "http://example.com/#home",
        "http://example.com/PokemonVortex/?", "http://example.com/PokemonVortex/#",
        "http://invalid_host/game/", "http://-invalid.example/game/", "http://bad..example/game/",
        "http://example.com/../game/", "http://example.com/%2e%2e/game/", "http://example.com/%252e%252e/game/",
        "http://example.com/Game%2fOther/", "http://example.com/Game%5cOther/", "http://example.com/Game\\Other/",
        "http://example.com/Game//Other/", "http://example.com/Game%00/", "http://example.com/Game%zz/",
        "http://example.com/Game Folder/", "http://example.com/\nGame/"];
    foreach (string address in invalid)
    {
        Check(!GameEndpoint.TryCreate(address, out GameEndpoint? endpoint, out string error), "Unexpectedly accepted: " + address);
        Check(endpoint is null && !string.IsNullOrWhiteSpace(error), "Invalid endpoint must have an error and no result.");
    }
}

static void AllowedNavigation()
{
    GameEndpoint endpoint = Endpoint("http://localhost:8080/PokemonVortex/");
    string[] paths = ["", "index.php", "login.php", "battle.php?id=42&action=attack", "maps/route-1.php#player",
        "ajax/battle.php?return=http%3A%2F%2Fexample.com%2F..%2F&message=%252f", "profile.php?name=Akuma",
        "assets/Pokemon%20Vortex.html"];
    foreach (string path in paths)
        Check(endpoint.IsAllowed("http://LOCALHOST:8080/PokemonVortex/" + path), "Rejected game route: " + path);
    Check(endpoint.IsAllowed("http://localhost:8080/PokemonVortex?route=home"), "Slashless root needs server redirect support.");
    Check(Endpoint("http://localhost/").IsAllowed("http://localhost:80/PokemonVortex/index.php"), "Default port equivalence failed.");
}

static void BlockedNavigation()
{
    GameEndpoint endpoint = Endpoint("http://localhost:8080/PokemonVortex/");
    string[] urls = ["http://localhost:8080/", "http://localhost:8080/OtherGame/", "https://localhost:8080/PokemonVortex/",
        "http://localhost/PokemonVortex/", "http://otherhost:8080/PokemonVortex/", "http://localhost.evil:8080/PokemonVortex/",
        "http://user@localhost:8080/PokemonVortex/", "http://localhost:8080/pokemonvortex/",
        "http://localhost:8080/PokemonVortexBackup/index.php", "http://localhost:8080/PokemonVortex/../admin.php",
        "http://localhost:8080/PokemonVortex/%2e%2E/admin.php", "http://localhost:8080/PokemonVortex/maps/./a.php",
        "http://localhost:8080/PokemonVortex/%252e%252e/admin.php", "http://localhost:8080/PokemonVortex/%2f../admin.php",
        "http://localhost:8080/PokemonVortex/%5Cadmin.php", "http://localhost:8080/PokemonVortex/%00.php",
        "http://localhost:8080/PokemonVortex//index.php", "http://localhost:8080/PokemonVortex/%zz.php",
        "file:///C:/PokemonVortex/index.php", "about:blank", "data:text/html,game", "javascript:alert(1)",
        "//localhost:8080/PokemonVortex/", "/PokemonVortex/index.php", "http://localhost:8080/PokemonVortex/index.php\r\n"];
    foreach (string url in urls)
        Check(!endpoint.IsAllowed(url), "Unexpectedly allowed: " + url);
}

static void HomeBoundary()
{
    GameEndpoint endpoint = Endpoint(GameEndpoint.DefaultAddress);
    foreach (string suffix in new[] { "", "index.php", "index.html", "?status=login", "index.php#news", "index.php?logout=1" })
        Check(endpoint.IsHome(GameEndpoint.DefaultAddress + suffix), "Not recognized as home: " + suffix);
    Check(endpoint.IsHome("http://127.0.0.1/PokemonVortex"), "Slashless base not home.");
    foreach (string suffix in new[] { "login.php", "maps/index.php", "index.php/extra", "Index.php", "index.htm" })
        Check(!endpoint.IsHome(GameEndpoint.DefaultAddress + suffix), "Incorrect home alias: " + suffix);
    Check(!endpoint.IsHome("http://evil.example/PokemonVortex/index.php"), "External home accepted.");
}

static void WithStore(Action<SettingsStore> action)
{
    string directory = Path.Combine(Path.GetTempPath(), "PokemonVortexNXT-Tests-" + Guid.NewGuid().ToString("N"));
    try { action(new SettingsStore(directory)); }
    finally { if (Directory.Exists(directory)) Directory.Delete(directory, recursive: true); }
}

static void SettingsRoundTrip() => WithStore(store =>
{
    AppSettings initial = store.Load();
    Equal(GameEndpoint.DefaultAddress, initial.ServerAddress);
    Check(!initial.IsMuted && store.LastLoadWarning is null, "First run defaults are incorrect.");
    var desired = new AppSettings { ServerAddress = "https://example.com:8443/MyGame", IsMuted = true,
        ZoomFactor = 1.25, WindowWidth = 1440, WindowHeight = 900, IsMaximized = true };
    store.Save(desired);
    AppSettings actual = new SettingsStore(store.DirectoryPath).Load();
    Equal("https://example.com:8443/MyGame/", actual.ServerAddress);
    Equal(desired.IsMuted, actual.IsMuted); Equal(desired.ZoomFactor, actual.ZoomFactor);
    Equal(desired.WindowWidth, actual.WindowWidth); Equal(desired.WindowHeight, actual.WindowHeight);
    Equal(desired.IsMaximized, actual.IsMaximized);
    Check(File.Exists(Path.Combine(store.DirectoryPath, "settings.json.bak")), "First save lacks recovery backup.");
    Check(!Directory.EnumerateFiles(store.DirectoryPath, "*.tmp").Any(), "Temporary settings files left behind.");
});

static void BackupRecovery() => WithStore(store =>
{
    store.Save(new AppSettings { ServerAddress = "http://localhost:8080/First/", IsMuted = true });
    store.Save(new AppSettings { ServerAddress = "http://localhost:8080/Second/" });
    string primary = Path.Combine(store.DirectoryPath, "settings.json");
    File.WriteAllText(primary, "{broken");
    AppSettings recovered = store.Load();
    Equal("http://localhost:8080/First/", recovered.ServerAddress);
    Check(recovered.IsMuted && store.LastLoadWarning is not null, "Recovery warning/state missing.");
    store.Save(new AppSettings { ServerAddress = "http://localhost:8080/Third/" });
    File.WriteAllText(primary, "null");
    Equal("http://localhost:8080/First/", store.Load().ServerAddress);
    File.Delete(primary);
    Equal("http://localhost:8080/First/", store.Load().ServerAddress);
});

static void CorruptionFallback() => WithStore(store =>
{
    Directory.CreateDirectory(store.DirectoryPath);
    string primary = Path.Combine(store.DirectoryPath, "settings.json");
    File.WriteAllText(primary, "{\"ServerAddress\":\"file:///tmp/game/\"}");
    Equal(GameEndpoint.DefaultAddress, store.Load().ServerAddress);
    Check(store.LastLoadWarning is not null, "Corrupt settings warning missing.");
    File.WriteAllText(primary, "{\"ZoomFactor\":999,\"WindowWidth\":-1,\"WindowHeight\":10}");
    AppSettings normalized = store.Load();
    Equal(2.0, normalized.ZoomFactor); Equal(800.0, normalized.WindowWidth); Equal(600.0, normalized.WindowHeight);
    Check(store.LastLoadWarning is not null, "Invalid display settings warning missing.");
    store.Save(new AppSettings { ZoomFactor = double.NaN, WindowWidth = double.PositiveInfinity });
    Equal(1.0, store.Load().ZoomFactor); Equal(1280.0, store.Load().WindowWidth);
    string before = File.ReadAllText(primary);
    bool rejected = false;
    try { store.Save(new AppSettings { ServerAddress = "http://localhost/../Escape/" }); }
    catch (ArgumentException) { rejected = true; }
    Check(rejected, "Saving invalid server settings must fail.");
    Equal(before, File.ReadAllText(primary));
});

static void ProfileIsolation() => WithStore(store =>
{
    string original = store.ProfileDirectory(Endpoint("http://EXAMPLE.com:80/Game/"));
    Equal(original, store.ProfileDirectory(Endpoint("http://example.com/Game")));
    Equal(original, new SettingsStore(store.DirectoryPath).ProfileDirectory(Endpoint("http://example.com/Game/")));
    foreach (string address in new[] { "https://example.com/Game/", "http://example.com:8080/Game/",
        "http://example.com/Other/", "http://other.example/Game/", "http://example.com/game/" })
        Check(original != store.ProfileDirectory(Endpoint(address)), "Shared browser data across endpoints: " + address);
    Equal(store.ProfileDirectory(Endpoint("https://bücher.example/Game/")),
        store.ProfileDirectory(Endpoint("https://xn--bcher-kva.example/Game/")));
    Equal(Path.Combine(store.DirectoryPath, "Profiles"), Path.GetDirectoryName(original));
    Equal(64, Path.GetFileName(original).Length);
    Check(Directory.Exists(original), "Profile directory not created.");
});
