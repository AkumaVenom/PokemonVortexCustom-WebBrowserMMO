@echo off
setlocal
title Pokemon Vortex NXT Desktop Shortcut
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install Desktop Shortcut.ps1"
set "shortcutExitCode=%ERRORLEVEL%"
echo.
pause
exit /b %shortcutExitCode%
