[CmdletBinding()]
param(
    [string]$ExePath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

try {
    if ([string]::IsNullOrWhiteSpace($ExePath)) {
        $candidates = @(
            (Join-Path $PSScriptRoot 'PokemonVortexNXT.exe'),
            (Join-Path (Split-Path -Parent $PSScriptRoot) 'dist\win-x64\PokemonVortexNXT.exe')
        )
        foreach ($candidate in $candidates) {
            if (Test-Path -LiteralPath $candidate -PathType Leaf) {
                $ExePath = $candidate
                break
            }
        }
    }

    if ([string]::IsNullOrWhiteSpace($ExePath) -or -not (Test-Path -LiteralPath $ExePath -PathType Leaf)) {
        throw 'PokemonVortexNXT.exe was not found. Build the client first, or run this script beside the published EXE. You can also supply -ExePath with the full EXE path.'
    }
    $resolvedExe = (Resolve-Path -LiteralPath $ExePath).ProviderPath
    if ([System.IO.Path]::GetExtension($resolvedExe) -ine '.exe') {
        throw 'ExePath must point to the published PokemonVortexNXT.exe application.'
    }
    $desktopDirectory = [Environment]::GetFolderPath([Environment+SpecialFolder]::DesktopDirectory)
    if ([string]::IsNullOrWhiteSpace($desktopDirectory)) {
        throw 'Windows did not provide a desktop directory for the current user.'
    }
    $shortcutPath = Join-Path $desktopDirectory 'Pokemon Vortex NXT.lnk'
    $shell = New-Object -ComObject WScript.Shell
    try {
        $shortcut = $shell.CreateShortcut($shortcutPath)
        $shortcut.TargetPath = $resolvedExe
        $shortcut.WorkingDirectory = Split-Path -Parent $resolvedExe
        $shortcut.IconLocation = '"' + $resolvedExe + '",0'
        $shortcut.Description = 'Play Pokemon Vortex NXT'
        $shortcut.Save()
    }
    finally {
        if ($null -ne $shell) {
            [void][System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($shell)
        }
    }
    Write-Host "Created: $shortcutPath" -ForegroundColor Green
    Write-Host 'Keep the client folder in this location so the shortcut continues to work.'
}
catch {
    Write-Error -Message $_.Exception.Message -ErrorAction Continue
    exit 1
}
exit 0
