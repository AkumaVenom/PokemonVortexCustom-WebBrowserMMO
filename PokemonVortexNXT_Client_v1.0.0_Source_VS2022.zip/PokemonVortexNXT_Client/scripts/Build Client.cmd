@echo off
setlocal
title Build Pokemon Vortex NXT Client
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0build.ps1"
set "buildExitCode=%ERRORLEVEL%"
echo.
if not "%buildExitCode%"=="0" echo Build failed. Review the error above.
pause
exit /b %buildExitCode%
