[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$projectRoot = Split-Path -Parent $PSScriptRoot
$testProject = Join-Path $projectRoot 'tests\PokemonVortexNXT.Core.Tests\PokemonVortexNXT.Core.Tests.csproj'
$solution = Join-Path $projectRoot 'PokemonVortexNXT.sln'
$clientProject = Join-Path $projectRoot 'src\PokemonVortexNXT.Client\PokemonVortexNXT.Client.csproj'
$publishDirectory = Join-Path $projectRoot 'dist\win-x64'

function Invoke-DotNet {
    param([Parameter(Mandatory = $true)][string[]]$Arguments)

    & dotnet @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw "dotnet $($Arguments[0]) failed with exit code $LASTEXITCODE."
    }
}

try {
    if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
        throw 'Install the .NET 8 SDK or Visual Studio 2022 17.8+ with the .NET desktop development workload, then reopen this script.'
    }
    foreach ($requiredFile in @($testProject, $solution, $clientProject)) {
        if (-not (Test-Path -LiteralPath $requiredFile -PathType Leaf)) {
            throw "Required project file is missing: $requiredFile. Extract the complete source ZIP before building."
        }
    }

    Push-Location -LiteralPath $projectRoot
    try {
        Write-Host 'Running core navigation and settings tests...' -ForegroundColor Cyan
        Invoke-DotNet -Arguments @('run', '--project', $testProject, '--configuration', 'Release')

        Write-Host 'Building Pokemon Vortex NXT...' -ForegroundColor Cyan
        Invoke-DotNet -Arguments @('build', $solution, '--configuration', 'Release', '--nologo')

        Write-Host 'Publishing the self-contained Windows x64 client...' -ForegroundColor Cyan
        Invoke-DotNet -Arguments @(
            'publish', $clientProject,
            '--configuration', 'Release',
            '--runtime', 'win-x64',
            '--self-contained', 'true',
            '-p:PublishSingleFile=false',
            '-p:PublishTrimmed=false',
            '--output', $publishDirectory,
            '--nologo'
        )

        $publishedExe = Join-Path $publishDirectory 'PokemonVortexNXT.exe'
        if (-not (Test-Path -LiteralPath $publishedExe -PathType Leaf)) {
            throw 'Publishing returned successfully but PokemonVortexNXT.exe was not found in the output directory.'
        }
        Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'Install Desktop Shortcut.ps1') -Destination $publishDirectory -Force
        Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'Install Desktop Shortcut.cmd') -Destination $publishDirectory -Force
        Copy-Item -LiteralPath (Join-Path $projectRoot 'docs\PLAYER-QUICKSTART.txt') -Destination (Join-Path $publishDirectory 'README.txt') -Force
        Copy-Item -LiteralPath (Join-Path $projectRoot 'licenses') -Destination $publishDirectory -Recurse -Force

        Write-Host ''
        Write-Host "Ready: $publishedExe" -ForegroundColor Green
        Write-Host 'Distribute the entire dist\win-x64 folder. The EXE depends on the accompanying files.'
        Write-Host 'The Microsoft Edge WebView2 Evergreen Runtime must also be installed on each player PC.'
    }
    finally {
        Pop-Location
    }
}
catch {
    Write-Error -Message $_.Exception.Message -ErrorAction Continue
    exit 1
}
exit 0
