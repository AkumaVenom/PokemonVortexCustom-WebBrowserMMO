# Pokemon Vortex NXT Client

A dedicated Windows client for Pokemon Vortex NXT, built with WPF and Microsoft Edge WebView2. It opens the game in a bright, resizable desktop window with the supplied Pokeball icon, native window controls, fullscreen, and a compact game toolbar.

The default landing address is **http://127.0.0.1/PokemonVortex/**. The game remains hosted by your existing web server; this client displays it using the Edge rendering engine.

## What the client provides

- A dedicated game window without an editable address bar; the server address is editable only in Advanced Settings.
- Home, Back, Reload, and saved client options.
- Navigation restricted to the configured server and game base path; external links and downloads are blocked. Allowed popup links open in the existing game view.
- Back disabled at the landing page, with browser history reset after each successful landing/index load to establish a fresh starting boundary.
- Minimize, maximize, resize, and fullscreen with **F11** or **Alt+Enter**. **Escape** exits fullscreen; in a normal window, Escape remains available to the game.
- Saved server address, client mute, zoom, and window preferences.
- Persistent browser storage in a separate profile for each server endpoint, keeping login cookies and site settings separate between servers.
- Edge's normal hardware acceleration and web media support through the installed WebView2 Evergreen Runtime.
- Sound enabled by default, with browser autoplay enabled and a saved client-wide mute option. The game's own saved audio preferences still apply.

The client does not replace the game's own music and effects controls, account system, multiplayer code, or server-side saving. It does not bundle a game server or alter game files.

## Build in Visual Studio 2022

1. Install **Visual Studio 2022 17.8 or later** with the **.NET desktop development** workload and **.NET 8 SDK**.
2. Extract the complete source package to a normal folder.
3. Open `PokemonVortexNXT.sln` and allow NuGet restore.
4. Select `PokemonVortexNXT.Client` as the startup project, if necessary, and build in **Release**.
5. For a distributable folder, run `scripts\Build Client.cmd`.

The build script runs the core checks, builds the solution, and publishes a **Windows x64 self-contained** client into `dist\win-x64`. Self-contained publishing includes the .NET runtime; **Microsoft Edge WebView2 Evergreen Runtime remains a separate prerequisite**. The first restore requires internet access to the configured NuGet source.

See [BUILD-AND-DISTRIBUTE.md](docs/BUILD-AND-DISTRIBUTE.md) for commands, dependencies, and release checks.

## Play

1. Start your existing Pokemon Vortex web server.
2. Open `PokemonVortexNXT.exe` from the complete published folder.
3. If the server is on another computer or uses a different path, open the client's options and change the saved server/base address.
4. Log in using your normal game account.

`127.0.0.1` always means **the computer running the client**. A friend joining your server must set your reachable server address in options. An origin-only address uses the default `/PokemonVortex/` path; enter the full base address when your installation uses a different path. A server address change switches the client to that endpoint's separate browser profile, so a fresh login may be required.

Run `Install Desktop Shortcut.cmd` from the published folder to create a desktop shortcut using the application's icon. Keep that folder in a permanent location before creating the shortcut.

If your desktop already has a shortcut named `Pokemon Vortex NXT` from the earlier launcher, this helper replaces it with a shortcut to the new client.

## Scope and verification

The supplied `pokemon.zip` contains **6,477 GIF sprites and `Thumbs.db`**, rather than the web game's PHP, JavaScript, or audio implementation. The client was designed around standard browser behavior; source-level integration with the game's actual login, battle, multiplayer, and audio systems could not be audited from that archive. The original sprite archive is not included in this client package.

The complete Release solution compiled with **zero warnings or errors**, with warnings treated as errors, and **all 9 core test groups passed**. Build details and the remaining Windows/game checks are recorded in [VALIDATION.md](docs/VALIDATION.md). Actual playback, performance, login persistence, and game behavior must be checked against your running installation. WebView2 provides Edge's engine, but a client wrapper cannot guarantee every site feature or 100% performance on every PC.

The Windows x64 self-contained publish also succeeded, using .NET runtime **8.0.31**. `PokemonVortexNXT_Client_v1.0.0_Windows_x64.zip` contains the ready-built client, and `PokemonVortexNXT_Client_v1.0.0_Source_VS2022.zip` contains the source for Visual Studio development. Windows launch and live-game testing remain to be completed on a Windows PC.

## Saved data and diagnostics

Client data lives under `%LOCALAPPDATA%\PokemonVortexNXT\Client\`. `settings.json` is written atomically and has a recovery backup; endpoint-specific browser profiles live under `Profiles\<endpoint-hash>`. A bounded `client.log` records local client diagnostics. These files are separate from your server's accounts and database and are not bundled into a normal publish.

## Project layout

| Path | Purpose |
| --- | --- |
| `PokemonVortexNXT.sln` | Visual Studio solution |
| `src/PokemonVortexNXT.Client/` | WPF window and WebView2 host |
| `src/PokemonVortexNXT.Core/` | Navigation and settings logic |
| `tests/PokemonVortexNXT.Core.Tests/` | Dependency-free console checks |
| `scripts/` | Windows build and desktop shortcut scripts |
| `docs/` | Player, build, and validation guidance |
