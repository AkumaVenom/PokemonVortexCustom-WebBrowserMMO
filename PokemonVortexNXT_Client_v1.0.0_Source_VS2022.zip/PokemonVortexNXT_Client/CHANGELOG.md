# Changelog

## 1.0.0 — Initial dedicated Windows client

- Added a WPF desktop host using Microsoft Edge WebView2.
- Set `http://127.0.0.1/PokemonVortex/` as the default game landing address.
- Added saved server/base address options and separate persistent browser profiles per endpoint.
- Added restricted game navigation, landing-page back behavior, Home, and Reload.
- Added a bright game window with the supplied icon, standard resizing and window controls, and fullscreen shortcuts.
- Added saved client mute, zoom, and window preferences.
- Added runtime/setup handling, core checks, Windows build scripts, a desktop shortcut helper, and distribution documentation.

See `docs/VALIDATION.md` for the exact verification status and required checks against a running Windows game server. No game server files are modified or bundled.
