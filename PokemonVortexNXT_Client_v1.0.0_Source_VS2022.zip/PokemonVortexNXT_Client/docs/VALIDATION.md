# Verification and acceptance checks

## Build record

The entries below must reflect actual checks. A successful compile verifies source compatibility; it does not verify Windows UI, a running web game, audio, or multiplayer behavior.

| Check | Status |
| --- | --- |
| Core console checks | Passed: all 9 of 9 test groups, executed from the actual Release binary |
| WPF solution compilation | Passed: complete Release solution with `-warnaserror`; zero warnings and zero errors |
| Windows x64 publish | Passed: self-contained Windows x64 publish with .NET SDK 8.0.425 and .NET runtime 8.0.31 |
| Published folder launch on Windows | Requires Windows runtime check |
| Live Pokemon Vortex game integration | Requires running game server |

Verified compiler/tool versions: **.NET SDK 8.0.425**, **MSBuild 17.11.48**, and **Microsoft.Web.WebView2 SDK 1.0.3650.58**. The compile and core checks do not constitute a Windows launch or live game test.

Release packages: `PokemonVortexNXT_Client_v1.0.0_Windows_x64.zip` contains the published client; `PokemonVortexNXT_Client_v1.0.0_Source_VS2022.zip` contains the Visual Studio source project. Actual Windows launch, UI behavior, audio, and live-game acceptance remain untested here.

The provided game archive contains 6,477 GIF sprites and a `Thumbs.db` file. It contains no PHP pages, JavaScript, or audio implementation. Consequently, those systems were not available for source-level integration review. The client uses normal WebView2 website behavior and does not inject gameplay code.

## Windows desktop acceptance

| Check | Expected result |
| --- | --- |
| Start the published EXE | A usable window appears with the supplied game icon and a loading state, followed by the landing page |
| Runtime missing | Native setup guidance appears with a Microsoft WebView2 installation route; no unexplained crash |
| Resize / minimize / maximize | Game view follows the window and remains usable after restore |
| F11 / Alt+Enter | Fullscreen toggles correctly and the prior window is restored |
| Escape | Exits fullscreen; remains available to game code in an ordinary window |
| Restart client | Saved mute, zoom, server, and window preferences return |
| Desktop shortcut | Opens the published client from its final folder and shows the game icon |
| Offline / server stopped | Clear failure/retry behavior; restoring the server and retrying loads the game |

## Address and navigation acceptance

1. On a fresh profile, verify the first page is `http://127.0.0.1/PokemonVortex/`.
2. Confirm the normal toolbar has no editable URL box and ordinary browser location/devtools shortcuts do not expose one. Server address editing must be available only through Advanced Settings.
3. Visit several game pages, use Back, and return Home. At the landing page, native Back must be disabled and a successful home/index load must establish a fresh browser history boundary, without an extra reload or POST replay.
4. Try game links, popups, and redirects outside the configured scheme/host/port/base path. They must not navigate the client away from the configured game area or automatically open another browser.
5. Save a valid alternative base address in client options, restart, and verify that address remains selected.
6. Confirm invalid inputs cannot replace the saved endpoint.
7. Check origin-only configuration selects `/PokemonVortex/`, and an explicitly configured alternative game folder loads under that folder.
8. Log into two test servers in turn. Verify their browser sessions and stored site data remain separate.
9. Confirm downloads are blocked and an allowed popup link opens in the current view. Test any real game form using `target="_blank"`; its submission method and payload need separate integration verification.

Navigation controls are a dedicated-client feature. They are not a replacement for the game server's authentication, authorization, or validation. Check the game's own JavaScript-driven history behavior during the real game acceptance pass as well as native Back.

## Live game acceptance

| Game area | What to verify |
| --- | --- |
| Account creation / login / logout | Forms submit, expected pages load, cookies persist correctly, logout clears the session as designed |
| Persistent account state | Inventory, party, progress, and other account state behave identically to the hosted game after refresh/restart |
| Maps and encounters | Rendering, movement, scrolling, encounters, and map transitions work at expected zoom |
| Multiplayer | Two accounts on two PCs can see and interact with the same server state as designed |
| Battles / captures | Turn controls, animations, capture results, rewards, and return-to-map flow work |
| Shops / missions / menus | Forms and internal navigation remain inside the configured game path and complete successfully |
| Music and effects | With default client sound enabled and autoplay permitted, battle effects and page music play without duplication; game-owned mute and audio logic remain respected |
| Audio settings | Test game music/effects levels, game mute persistence, and client-wide mute independently; restart after changing client mute |
| Page refresh / restart | Game-owned playback position and account preferences restore if the game implements them |
| Fullscreen input | Keyboard/mouse controls and game dialogs work before, during, and after fullscreen |
| Longer session | No accumulating duplicate audio, repeated popup loops, or obvious sustained memory growth during normal play |

Use a second Windows machine for the remote-server check. `127.0.0.1` on that PC refers to that PC; save the host's reachable address before trying multiplayer.

Performance depends on the game, the server, PC hardware, network, and installed WebView2 version. Confirm gameplay against your actual deployment rather than treating engine compatibility as a performance guarantee.
