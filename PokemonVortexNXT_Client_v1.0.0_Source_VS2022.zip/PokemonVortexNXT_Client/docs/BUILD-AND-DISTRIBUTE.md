# Build and distribute

## Prerequisites

- Windows with Visual Studio 2022 17.8+ and the .NET desktop development workload, or the .NET 8 SDK for command-line builds.
- Internet access for the initial NuGet restore.
- Microsoft Edge WebView2 Evergreen Runtime on every PC that runs the client. Installing Edge alone should not be used as the deployment check; the client checks WebView2 availability and presents setup guidance when it is missing.

The application is a Windows WPF program. Core logic can be exercised elsewhere with the .NET SDK, but the actual window, WebView2 interaction, and audio require Windows for runtime validation.

The WebView2 host follows Microsoft's supported WPF integration model. See the [official WebView2 WPF setup guide](https://learn.microsoft.com/en-us/microsoft-edge/webview2/get-started/wpf). Runtime deployment uses Evergreen, which requires an installed WebView2 Runtime on the player PC; see [Microsoft's WebView2 distribution guidance](https://learn.microsoft.com/en-us/microsoft-edge/webview2/concepts/distribution).

The verified Release build used .NET SDK **8.0.425**, MSBuild **17.11.48**, and WebView2 SDK **1.0.3650.58**. Windows x64 self-contained publication succeeded with .NET runtime **8.0.31**. See `VALIDATION.md` for the complete build record and remaining Windows/game checks.

## Recommended build

Double-click `scripts\Build Client.cmd` after extracting the complete source ZIP. It invokes the local PowerShell build script, runs the core checks, builds Release, and publishes to `dist\win-x64`.

The `.cmd` helpers use `-ExecutionPolicy Bypass` for their own PowerShell process only. They do not change the machine's execution policy, install software, or require administrator privileges. If an organization's policy blocks scripts, use your approved development environment and the direct commands below.

From a terminal in the source root:

```powershell
dotnet run --project tests/PokemonVortexNXT.Core.Tests/PokemonVortexNXT.Core.Tests.csproj --configuration Release
dotnet build PokemonVortexNXT.sln --configuration Release
dotnet publish src/PokemonVortexNXT.Client/PokemonVortexNXT.Client.csproj --configuration Release --runtime win-x64 --self-contained true -p:PublishSingleFile=false -p:PublishTrimmed=false --output dist/win-x64
```

These direct commands publish the application. The build script also copies the player README and shortcut helpers into the published folder.

## Distribution

The release provides `PokemonVortexNXT_Client_v1.0.0_Windows_x64.zip` for players and `PokemonVortexNXT_Client_v1.0.0_Source_VS2022.zip` for source development. Players extract the entire Windows ZIP and run `PokemonVortexNXT.exe`; they do not need to compile the source package.

1. Finish the Windows and game checks in `VALIDATION.md`.
2. Copy the entire `dist\win-x64` folder to a fresh location and launch the EXE there.
3. Zip that complete folder and share it with players.
4. Tell players your reachable game base address when they are joining a remote server.

Keep all generated DLLs, configuration files, native loader files, and supporting folders. **Do not distribute only the EXE.** Publishing intentionally leaves single-file bundling and trimming disabled, preserving the WebView2 and WPF dependencies. The x64 package is intended for Windows x64.

The self-contained package includes its .NET runtime. WebView2 Evergreen Runtime is maintained separately by Microsoft and must be installed for the client to start its browser. This package does not silently install or download it, does not include a web server or database, and does not contain the uploaded sprite archive.

## Desktop shortcut

The build script puts `Install Desktop Shortcut.cmd` and `.ps1` beside the published EXE. Run the `.cmd` after moving the client to its permanent location. It creates or updates the current user's `Pokemon Vortex NXT` desktop shortcut with the executable's icon.

For a custom EXE location:

```powershell
& '.\scripts\Install Desktop Shortcut.ps1' -ExePath 'C:\Games\Pokemon Vortex NXT\PokemonVortexNXT.exe'
```

The shortcut helper can also be run from the source `scripts` directory after a normal publish. Moving the client folder later requires running the helper again.

An existing desktop shortcut named `Pokemon Vortex NXT`, including one created by the earlier Edge launcher, is replaced intentionally. Other desktop shortcuts are unchanged.

## Server configuration

The initial address is `http://127.0.0.1/PokemonVortex/`. This is useful for a local XAMPP installation. Each player can save another server/base address from client options; there is no general browsing address bar.

Use the full game base address when your installation is not at `/PokemonVortex/`. An origin-only address uses that default folder. The configured scheme, host, port, and base path define the allowed navigation area. Other sites, sibling applications, and external protocols are blocked.

Only Advanced Settings permits editing the server address. Downloads are disabled. Allowed new-window URLs are reopened in the current game view; test any actual game form that uses `target="_blank"`, since a popup request is not a guarantee that form POST data will be preserved by this behavior.

Changing the client address does not configure Apache, change database credentials, open ports, or make a private server public. Browser state is kept separately per endpoint. Game account data remains wherever the game's server stores it.

## Landing history and audio

After a successful home/index load, the client resets navigation history through Chromium's [`Page.resetNavigationHistory`](https://chromedevtools.github.io/devtools-protocol/tot/Page/#method-resetNavigationHistory). This establishes the landing boundary without reloading the page or replaying a POST. A native Back guard remains in place if that optional runtime command fails. Test the game's own JavaScript history controls against the real installation.

The browser environment is configured with `--autoplay-policy=no-user-gesture-required`, and the client defaults to unmuted. This permits browser autoplay; it does not override game-owned mute preferences, paused audio code, missing files, or account-side playback restoration. The client mute control applies to the whole hosted view.

## Local client data

| Location under `%LOCALAPPDATA%\PokemonVortexNXT\Client\` | Contents |
| --- | --- |
| `settings.json` | Saved server, mute, zoom, and window preferences |
| `settings.json.bak` | Recovery copy from atomic settings updates |
| `Profiles\<endpoint-hash>\` | Separate WebView2 cookies, cache, and website storage for each endpoint |
| `client.log` | Bounded local diagnostic log |

Do not remove profile data while the client is running. Profile contents belong to the individual Windows user and are not a substitute for backing up the game server's database.

## Updating

Build the new release into a fresh distribution folder and verify it before sharing. Players should close the running client before replacing its published files. Client settings and browser profiles are stored outside the application folder; copying the folder alone does not transfer a player's account session.

Do not include your own browser profile or local settings in a release archive. No such player state is part of a normal `dotnet publish` output.
