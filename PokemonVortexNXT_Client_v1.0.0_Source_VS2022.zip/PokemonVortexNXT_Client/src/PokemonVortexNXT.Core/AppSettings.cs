namespace PokemonVortexNXT.Core;

/// <summary>Per-user client preferences; game account data remains on the game server.</summary>
public sealed class AppSettings
{
    public string ServerAddress { get; set; } = GameEndpoint.DefaultAddress;
    public bool IsMuted { get; set; }
    public double ZoomFactor { get; set; } = 1.0;
    public double WindowWidth { get; set; } = 1280;
    public double WindowHeight { get; set; } = 840;
    public bool IsMaximized { get; set; }
}
