using System.Globalization;

namespace PokemonVortexNXT.Core;

/// <summary>Canonical server location and the allowed top-level navigation boundary.</summary>
public sealed class GameEndpoint
{
    public const string DefaultAddress = "http://127.0.0.1/PokemonVortex/";
    private const string DefaultDirectory = "/PokemonVortex/";
    private readonly string _directory;
    private readonly string _directoryWithoutSlash;

    public Uri HomeUri { get; }
    public string Origin { get; }

    private GameEndpoint(Uri homeUri)
    {
        HomeUri = homeUri;
        Origin = homeUri.GetLeftPart(UriPartial.Authority);
        _directory = homeUri.AbsolutePath;
        _directoryWithoutSlash = _directory.TrimEnd('/');
    }

    /// <summary>Accepts an HTTP(S) origin or the directory containing the game.</summary>
    public static bool TryCreate(string? input, out GameEndpoint? endpoint, out string error)
    {
        endpoint = null;
        error = string.Empty;
        string address = input?.Trim() ?? string.Empty;
        if (!TryParseHttpAddress(address, out Uri? parsed, out error))
            return false;

        if (address.Contains('?') || address.Contains('#'))
        {
            error = "Enter a server address and game folder without a query or fragment.";
            return false;
        }

        string directory = parsed!.AbsolutePath;
        if (directory == "/")
            directory = DefaultDirectory;
        else if (!directory.EndsWith('/'))
            directory += "/";

        // UriBuilder canonicalizes host casing, IDNs and default ports without
        // changing the case of the game directory (which matters on Linux hosts).
        var builder = new UriBuilder(parsed.Scheme, parsed.IdnHost,
            parsed.IsDefaultPort ? -1 : parsed.Port, directory);
        endpoint = new GameEndpoint(builder.Uri);
        return true;
    }

    /// <summary>Checks a complete navigation URL; ordinary PHP query strings are allowed.</summary>
    public bool IsAllowed(string? target)
    {
        if (!TryParseHttpAddress(target ?? string.Empty, out Uri? uri, out _))
            return false;

        return string.Equals(uri!.Scheme, HomeUri.Scheme, StringComparison.OrdinalIgnoreCase)
            && string.Equals(uri.IdnHost, HomeUri.IdnHost, StringComparison.OrdinalIgnoreCase)
            && uri.Port == HomeUri.Port
            && (uri.AbsolutePath.StartsWith(_directory, StringComparison.Ordinal)
                || string.Equals(uri.AbsolutePath, _directoryWithoutSlash, StringComparison.Ordinal));
    }

    /// <summary>Treats the directory and its common index aliases as the history floor.</summary>
    public bool IsHome(string? target)
    {
        if (!IsAllowed(target))
            return false;
        string path = new Uri(target!, UriKind.Absolute).AbsolutePath;
        return string.Equals(path, _directory, StringComparison.Ordinal)
            || string.Equals(path, _directoryWithoutSlash, StringComparison.Ordinal)
            || string.Equals(path, _directory + "index.php", StringComparison.Ordinal)
            || string.Equals(path, _directory + "index.html", StringComparison.Ordinal);
    }

    private static bool TryParseHttpAddress(string address, out Uri? uri, out string error)
    {
        uri = null;
        error = "Enter a complete http:// or https:// server address.";
        if (string.IsNullOrEmpty(address) || address.Length > 8192
            || address.Any(char.IsWhiteSpace) || address.Any(char.IsControl)
            || address.Contains('\\'))
            return false;

        int schemeEnd = address.IndexOf("://", StringComparison.Ordinal);
        if (schemeEnd < 0 || (!address[..schemeEnd].Equals("http", StringComparison.OrdinalIgnoreCase)
            && !address[..schemeEnd].Equals("https", StringComparison.OrdinalIgnoreCase)))
            return false;

        if (!Uri.TryCreate(address, UriKind.Absolute, out uri)
            || (uri.Scheme != Uri.UriSchemeHttp && uri.Scheme != Uri.UriSchemeHttps)
            || string.IsNullOrEmpty(uri.Host) || uri.UserInfo.Length != 0)
        {
            uri = null;
            return false;
        }

        int authorityStart = schemeEnd + 3;
        int authorityEnd = address.IndexOfAny(['/', '?', '#'], authorityStart);
        if (authorityEnd < 0)
            authorityEnd = address.Length;
        string authority = address[authorityStart..authorityEnd];
        if (authority.Length == 0 || authority.Contains('@') || authority.Contains('%')
            || !IsValidHost(uri))
        {
            error = "The server host is invalid. Do not include a username or password.";
            uri = null;
            return false;
        }

        // Inspect the original path before System.Uri removes dot segments.
        // Encoded separators and percent signs can be interpreted differently
        // by web servers, so they are not accepted in the navigation path.
        int pathEnd = address.IndexOfAny(['?', '#'], authorityEnd);
        if (pathEnd < 0)
            pathEnd = address.Length;
        string rawPath = address[authorityEnd..pathEnd];
        if (!IsUnambiguousPath(rawPath))
        {
            error = "The game path cannot contain traversal segments or encoded path separators.";
            uri = null;
            return false;
        }

        error = string.Empty;
        return true;
    }

    private static bool IsValidHost(Uri uri)
    {
        if (uri.HostNameType is UriHostNameType.IPv4 or UriHostNameType.IPv6)
            return true;
        if (uri.HostNameType != UriHostNameType.Dns)
            return false;

        string host;
        try { host = new IdnMapping().GetAscii(uri.DnsSafeHost.TrimEnd('.')); }
        catch (ArgumentException) { return false; }
        if (host.Length is 0 or > 253)
            return false;
        foreach (string label in host.Split('.'))
        {
            if (label.Length is 0 or > 63 || label[0] == '-' || label[^1] == '-'
                || label.Any(c => !char.IsAsciiLetterOrDigit(c) && c != '-'))
                return false;
        }
        return true;
    }

    private static bool IsUnambiguousPath(string rawPath)
    {
        if (rawPath.Contains("//", StringComparison.Ordinal))
            return false;
        for (int index = 0; index < rawPath.Length; index++)
        {
            if (rawPath[index] != '%')
                continue;
            if (index + 2 >= rawPath.Length || !Uri.IsHexDigit(rawPath[index + 1])
                || !Uri.IsHexDigit(rawPath[index + 2]))
                return false;
            int value = (HexValue(rawPath[index + 1]) << 4) | HexValue(rawPath[index + 2]);
            if (value is 0x2f or 0x5c or 0x25 || value < 0x20 || value == 0x7f)
                return false;
            index += 2;
        }

        foreach (string segment in rawPath.Split('/'))
        {
            string decoded = Uri.UnescapeDataString(segment);
            if (decoded is "." or ".." || decoded.Any(char.IsControl))
                return false;
        }
        return true;
    }

    private static int HexValue(char value) => value <= '9'
        ? value - '0' : char.ToUpperInvariant(value) - 'A' + 10;
}
