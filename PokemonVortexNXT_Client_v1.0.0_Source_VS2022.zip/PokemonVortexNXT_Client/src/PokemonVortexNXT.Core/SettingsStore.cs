using System.Security;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace PokemonVortexNXT.Core;

/// <summary>Atomic per-user settings with recovery and isolated browser profiles.</summary>
public sealed class SettingsStore
{
    private const int MaximumSettingsBytes = 1024 * 1024;
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNameCaseInsensitive = true,
        WriteIndented = true,
        MaxDepth = 16
    };
    private readonly object _gate = new();
    private readonly string _settingsFile;
    private readonly string _backupFile;

    public string DirectoryPath { get; }
    public string? LastLoadWarning { get; private set; }

    public SettingsStore(string directory)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(directory);
        DirectoryPath = Path.GetFullPath(directory);
        _settingsFile = Path.Combine(DirectoryPath, "settings.json");
        _backupFile = Path.Combine(DirectoryPath, "settings.json.bak");
    }

    public AppSettings Load()
    {
        lock (_gate)
        {
            LastLoadWarning = null;
            if (TryRead(_settingsFile, out AppSettings? settings, out bool corrected))
            {
                if (corrected)
                    LastLoadWarning = "Some saved display settings were reset to supported values.";
                return settings!;
            }

            if (TryRead(_backupFile, out settings, out _))
            {
                LastLoadWarning = "Client settings were recovered from the last valid backup.";
                return settings!;
            }

            if (File.Exists(_settingsFile) || File.Exists(_backupFile))
                LastLoadWarning = "Client settings could not be read. Default settings have been loaded.";
            return new AppSettings();
        }
    }

    /// <summary>Writes a complete replacement and retains the previous valid settings.</summary>
    public void Save(AppSettings settings)
    {
        ArgumentNullException.ThrowIfNull(settings);
        AppSettings normalized = Normalize(settings, out _);
        lock (_gate)
        {
            Directory.CreateDirectory(DirectoryPath);
            string temporaryFile = WriteTemporary(normalized);
            try
            {
                if (File.Exists(_settingsFile) && TryRead(_settingsFile, out _, out _))
                    File.Replace(temporaryFile, _settingsFile, _backupFile, ignoreMetadataErrors: true);
                else
                    File.Move(temporaryFile, _settingsFile, overwrite: true);

                // Also protect the first save, and never replace a good backup
                // with the corrupt primary that was just recovered.
                if (!TryRead(_backupFile, out _, out _))
                {
                    string temporaryBackup = WriteTemporary(normalized);
                    try { File.Move(temporaryBackup, _backupFile, overwrite: true); }
                    finally { DeleteTemporary(temporaryBackup); }
                }
            }
            finally { DeleteTemporary(temporaryFile); }
        }
    }

    /// <summary>Returns a stable directory keyed by origin and case-sensitive game path.</summary>
    public string ProfileDirectory(GameEndpoint endpoint)
    {
        ArgumentNullException.ThrowIfNull(endpoint);
        string identity = endpoint.Origin + endpoint.HomeUri.AbsolutePath;
        string key = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(identity))).ToLowerInvariant();
        string path = Path.Combine(DirectoryPath, "Profiles", key);
        Directory.CreateDirectory(path);
        return path;
    }

    private static bool TryRead(string path, out AppSettings? settings, out bool corrected)
    {
        settings = null;
        corrected = false;
        try
        {
            using var file = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
            if (file.Length > MaximumSettingsBytes)
                return false;
            AppSettings? parsed = JsonSerializer.Deserialize<AppSettings>(file, JsonOptions);
            if (parsed is null)
                return false;
            settings = Normalize(parsed, out corrected);
            return true;
        }
        catch (Exception exception) when (exception is IOException or UnauthorizedAccessException
            or SecurityException or JsonException or ArgumentException or NotSupportedException)
        {
            return false;
        }
    }

    private string WriteTemporary(AppSettings settings)
    {
        string path = Path.Combine(DirectoryPath, ".settings-" + Guid.NewGuid().ToString("N") + ".tmp");
        try
        {
            using var file = new FileStream(path, FileMode.CreateNew, FileAccess.Write,
                FileShare.None, 4096, FileOptions.WriteThrough);
            JsonSerializer.Serialize(file, settings, JsonOptions);
            file.Flush(flushToDisk: true);
            return path;
        }
        catch
        {
            DeleteTemporary(path);
            throw;
        }
    }

    private static AppSettings Normalize(AppSettings settings, out bool corrected)
    {
        if (!GameEndpoint.TryCreate(settings.ServerAddress, out GameEndpoint? endpoint, out string error))
            throw new ArgumentException(error, nameof(settings));
        var normalized = new AppSettings
        {
            ServerAddress = endpoint!.HomeUri.AbsoluteUri,
            IsMuted = settings.IsMuted,
            ZoomFactor = SafeNumber(settings.ZoomFactor, 0.5, 2.0, 1.0),
            WindowWidth = SafeNumber(settings.WindowWidth, 800, 7680, 1280),
            WindowHeight = SafeNumber(settings.WindowHeight, 600, 4320, 840),
            IsMaximized = settings.IsMaximized
        };
        corrected = normalized.ZoomFactor != settings.ZoomFactor
            || normalized.WindowWidth != settings.WindowWidth
            || normalized.WindowHeight != settings.WindowHeight;
        return normalized;
    }

    private static double SafeNumber(double value, double minimum, double maximum, double fallback)
        => double.IsFinite(value) ? Math.Clamp(value, minimum, maximum) : fallback;

    private static void DeleteTemporary(string path)
    {
        try { File.Delete(path); }
        catch (IOException) { }
        catch (UnauthorizedAccessException) { }
    }
}
