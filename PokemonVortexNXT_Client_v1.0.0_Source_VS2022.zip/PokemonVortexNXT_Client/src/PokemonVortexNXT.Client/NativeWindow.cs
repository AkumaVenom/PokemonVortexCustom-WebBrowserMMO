using System.Diagnostics;
using System.Runtime.InteropServices;

namespace PokemonVortexNXT.Client;

internal static class NativeWindow
{
    [StructLayout(LayoutKind.Sequential)] internal struct Point { public int X, Y; }
    [StructLayout(LayoutKind.Sequential)] internal struct Rect { public int Left, Top, Right, Bottom; }
    [StructLayout(LayoutKind.Sequential)] private struct MonitorInfo
    {
        public int Size; public Rect Monitor, Work; public uint Flags;
    }
    [StructLayout(LayoutKind.Sequential)] private struct MinMaxInfo
    {
        public Point Reserved, MaxSize, MaxPosition, MinTrackSize, MaxTrackSize;
    }

    [DllImport("user32.dll")] private static extern IntPtr MonitorFromWindow(IntPtr hwnd, uint flags);
    [DllImport("user32.dll", CharSet = CharSet.Auto)] [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GetMonitorInfo(IntPtr monitor, ref MonitorInfo info);
    [DllImport("user32.dll")] [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool SetWindowPos(IntPtr hwnd, IntPtr after, int x, int y, int width, int height, uint flags);
    [DllImport("user32.dll")] [return: MarshalAs(UnmanagedType.Bool)] private static extern bool SetForegroundWindow(IntPtr hwnd);
    [DllImport("user32.dll")] [return: MarshalAs(UnmanagedType.Bool)] private static extern bool ShowWindow(IntPtr hwnd, int command);
    [DllImport("user32.dll")] [return: MarshalAs(UnmanagedType.Bool)] private static extern bool IsIconic(IntPtr hwnd);

    private static MonitorInfo? MonitorFor(IntPtr hwnd)
    {
        var monitor = MonitorFromWindow(hwnd, 2);
        var info = new MonitorInfo { Size = Marshal.SizeOf<MonitorInfo>() };
        return monitor != IntPtr.Zero && GetMonitorInfo(monitor, ref info) ? info : null;
    }

    internal static void SizeToMonitor(IntPtr hwnd)
    {
        if (MonitorFor(hwnd) is not { } info) return;
        var rect = info.Monitor;
        // Physical monitor coordinates support secondary screens and mixed DPI.
        SetWindowPos(hwnd, IntPtr.Zero, rect.Left, rect.Top, rect.Right - rect.Left,
            rect.Bottom - rect.Top, 0x0004 | 0x0020);
    }

    internal static bool AdjustMaximizedBounds(IntPtr hwnd, IntPtr lParam, bool fullscreen, int minimumWidth, int minimumHeight)
    {
        if (MonitorFor(hwnd) is not { } info) return false;
        var size = Marshal.PtrToStructure<MinMaxInfo>(lParam);
        var target = fullscreen ? info.Monitor : info.Work;
        size.MaxPosition.X = target.Left - info.Monitor.Left;
        size.MaxPosition.Y = target.Top - info.Monitor.Top;
        size.MaxSize.X = target.Right - target.Left;
        size.MaxSize.Y = target.Bottom - target.Top;
        size.MinTrackSize.X = fullscreen ? 0 : minimumWidth;
        size.MinTrackSize.Y = fullscreen ? 0 : minimumHeight;
        Marshal.StructureToPtr(size, lParam, false);
        return true;
    }

    internal static void ActivateExistingInstance()
    {
        using var current = Process.GetCurrentProcess();
        foreach (var process in Process.GetProcessesByName(current.ProcessName))
        {
            using (process)
            {
                try
                {
                    if (process.Id == current.Id || process.SessionId != current.SessionId) continue;
                    var handle = process.MainWindowHandle;
                    if (handle == IntPtr.Zero) continue;
                    if (IsIconic(handle)) ShowWindow(handle, 9);
                    SetForegroundWindow(handle);
                    return;
                }
                catch (InvalidOperationException) { }
                catch (System.ComponentModel.Win32Exception) { }
            }
        }
    }
}
