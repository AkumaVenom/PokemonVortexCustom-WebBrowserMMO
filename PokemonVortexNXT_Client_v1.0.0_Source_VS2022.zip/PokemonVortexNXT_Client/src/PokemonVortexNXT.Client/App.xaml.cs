using System.Diagnostics;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Windows;

namespace PokemonVortexNXT.Client;

public partial class App : Application
{
    public static string DataDirectory { get; } = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "PokemonVortexNXT", "Client");
    private Mutex? _instanceMutex;
    private bool _ownsMutex;

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        try
        {
            var userKey = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(DataDirectory)))[..16];
            _instanceMutex = new Mutex(true, @"Local\PokemonVortexNXT.Client." + userKey, out _ownsMutex);
            if (!_ownsMutex)
            {
                NativeWindow.ActivateExistingInstance();
                Shutdown();
                return;
            }
            Directory.CreateDirectory(DataDirectory);
            MainWindow = new MainWindow();
            MainWindow.Show();
        }
        catch (Exception ex)
        {
            Log(ex);
            MessageBox.Show("The client could not start. Check that your Windows account can write to its local application data folder.\n\n" + ex.Message,
                "Pokemon Vortex NXT", MessageBoxButton.OK, MessageBoxImage.Error);
            Shutdown(1);
        }
    }

    internal static void Log(Exception exception)
    {
        try
        {
            Directory.CreateDirectory(DataDirectory);
            var path = Path.Combine(DataDirectory, "client.log");
            if (File.Exists(path) && new FileInfo(path).Length > 1024 * 1024)
                File.Move(path, path + ".previous", true);
            File.AppendAllText(path, $"{DateTimeOffset.Now:O} {exception}\n\n");
        }
        catch { /* Logging must not prevent recovery or shutdown. */ }
    }

    protected override void OnExit(ExitEventArgs e)
    {
        if (_ownsMutex) _instanceMutex?.ReleaseMutex();
        _instanceMutex?.Dispose();
        base.OnExit(e);
    }
}
