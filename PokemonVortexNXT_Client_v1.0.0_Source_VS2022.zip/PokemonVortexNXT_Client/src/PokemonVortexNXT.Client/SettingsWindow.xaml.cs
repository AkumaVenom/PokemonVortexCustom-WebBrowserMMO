using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using PokemonVortexNXT.Core;

namespace PokemonVortexNXT.Client;

public partial class SettingsWindow : Window
{
    public GameEndpoint? SelectedEndpoint { get; private set; }
    public double SelectedZoom { get; private set; }
    public bool SelectedMuted { get; private set; }

    public SettingsWindow(AppSettings settings)
    {
        ArgumentNullException.ThrowIfNull(settings);
        InitializeComponent();

        ServerAddressBox.Text = settings.ServerAddress;
        MuteCheckBox.IsChecked = settings.IsMuted;
        SelectedMuted = settings.IsMuted;
        SelectedZoom = double.IsFinite(settings.ZoomFactor) && settings.ZoomFactor > 0
            ? settings.ZoomFactor
            : 1.0;

        // Preserve a supported custom value from saved settings instead of
        // replacing it when an unrelated option changes.
        var factors = new List<double> { 0.75, 0.90, 1.0, 1.10, 1.25, 1.50 };
        if (!factors.Any(factor => Math.Abs(factor - SelectedZoom) < 0.0000001))
            factors.Add(SelectedZoom);

        foreach (double factor in factors.OrderBy(factor => factor))
        {
            var item = new ComboBoxItem
            {
                Content = (factor * 100).ToString("0.##", CultureInfo.CurrentCulture) + "%",
                Tag = factor
            };
            ZoomComboBox.Items.Add(item);
            if (Math.Abs(factor - SelectedZoom) < 0.0000001)
                ZoomComboBox.SelectedItem = item;
        }
    }

    private void ResetServer_Click(object sender, RoutedEventArgs e)
    {
        ServerAddressBox.Text = GameEndpoint.DefaultAddress;
        ValidationMessage.Visibility = Visibility.Collapsed;
        ServerAddressBox.Focus();
        ServerAddressBox.SelectAll();
    }

    private void Save_Click(object sender, RoutedEventArgs e)
    {
        if (!GameEndpoint.TryCreate(ServerAddressBox.Text, out GameEndpoint? endpoint, out string error))
        {
            ServerExpander.IsExpanded = true;
            ValidationMessage.Text = error;
            ValidationMessage.Visibility = Visibility.Visible;
            ServerAddressBox.Focus();
            ServerAddressBox.SelectAll();
            ServerAddressBox.BringIntoView();
            return;
        }

        SelectedEndpoint = endpoint;
        SelectedMuted = MuteCheckBox.IsChecked == true;
        if (ZoomComboBox.SelectedItem is ComboBoxItem { Tag: double factor })
            SelectedZoom = factor;

        DialogResult = true;
    }
}
