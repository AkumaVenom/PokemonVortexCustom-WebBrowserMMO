using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Shell;
using System.Windows.Media;
using System.Windows.Threading;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.Wpf;
using PokemonVortexNXT.Core;

namespace PokemonVortexNXT.Client;

public partial class MainWindow : Window
{
    private readonly SettingsStore _store;
    private readonly AppSettings _settings;
    private GameEndpoint _endpoint;
    private WebView2? _browser;
    private bool _initializing, _closing, _fullScreen, _browserFaulted;
    private ulong _activeNavigation;
    private int _browserGeneration;
    private bool _hasPage;
    private bool _documentFullscreen, _historyResetPending;
    private Rect _beforeFullscreen;
    private WindowState _stateBeforeFullscreen;
    private WindowChrome? _normalChrome;
    private HwndSource? _windowSource;

    public MainWindow()
    {
        _store = new SettingsStore(App.DataDirectory);
        _settings = _store.Load();
        GameEndpoint.TryCreate(_settings.ServerAddress, out var endpoint, out _);
        _endpoint = endpoint!;
        InitializeComponent();
        Width = Math.Clamp(_settings.WindowWidth, MinWidth, Math.Max(MinWidth, SystemParameters.WorkArea.Width));
        Height = Math.Clamp(_settings.WindowHeight, MinHeight, Math.Max(MinHeight, SystemParameters.WorkArea.Height));
        if (_settings.IsMaximized) WindowState = WindowState.Maximized;
        UpdateSoundButton();
    }

    private async void Window_Loaded(object sender, RoutedEventArgs e)
    {
        await InitializeBrowserAsync();
        if (_store.LastLoadWarning is { Length: > 0 } warning) StatusText.Text = warning;
    }

    private async Task InitializeBrowserAsync()
    {
        if (_initializing || _closing) return;
        _initializing = true;
        OptionsButton.IsEnabled = false;
        RecoveryOptionsButton.IsEnabled = false;
        RetryButton.IsEnabled = false;
        _hasPage = false;
        _historyResetPending = false;
        _browserFaulted = false;
        var generation = ++_browserGeneration;
        DisposeBrowser();
        ShowPanel("Welcome, Trainer.", "Getting your adventure ready…", loading: true);
        StatusText.Text = "Starting game client…";
        try
        {
            // Check installed Evergreen runtime before control initialization for a useful setup screen.
            _ = CoreWebView2Environment.GetAvailableBrowserVersionString();
            var options = new CoreWebView2EnvironmentOptions("--autoplay-policy=no-user-gesture-required");
            var environment = await CoreWebView2Environment.CreateAsync(null, _store.ProfileDirectory(_endpoint), options);
            if (_closing || generation != _browserGeneration) return;
            var browser = new WebView2
            {
                DefaultBackgroundColor = System.Drawing.Color.White,
                AllowExternalDrop = false,
                Visibility = Visibility.Hidden
            };
            _browser = browser;
            BrowserHost.Children.Add(browser);
            await browser.EnsureCoreWebView2Async(environment);
            if (_closing || generation != _browserGeneration) return;
            var core = browser.CoreWebView2;
            var settings = core.Settings;
            settings.AreDevToolsEnabled = false;
            settings.AreDefaultContextMenusEnabled = false;
            settings.AreBrowserAcceleratorKeysEnabled = false;
            settings.IsStatusBarEnabled = false;
            settings.IsZoomControlEnabled = false;
            settings.IsSwipeNavigationEnabled = false;
            settings.IsBuiltInErrorPageEnabled = false;
            settings.AreHostObjectsAllowed = false;
            settings.IsWebMessageEnabled = false;
            // Keep standard JavaScript, DOM, dialogs, cookies, storage, codecs and Edge user agent.
            core.IsMuted = _settings.IsMuted;
            browser.ZoomFactor = _settings.ZoomFactor;
            core.NavigationStarting += NavigationStarting;
            core.NavigationCompleted += NavigationCompleted;
            core.SourceChanged += SourceChanged;
            core.HistoryChanged += (_, _) => { if (IsCurrent(core)) UpdateNavigationButtons(); };
            core.DocumentTitleChanged += (_, _) => { if (IsCurrent(core)) UpdatePageTitle(); };
            core.NewWindowRequested += NewWindowRequested;
            core.DownloadStarting += (_, args) =>
            {
                args.Cancel = true;
                if (!IsCurrent(core)) return;
                StatusText.Text = "File downloads are unavailable in the game client.";
            };
            core.WindowCloseRequested += (_, _) => { if (IsCurrent(core)) StatusText.Text = "Use the client’s Close button to leave the game."; };
            core.ProcessFailed += (_, args) =>
            {
                if (!IsCurrent(core)) return;
                // GPU/subframe failures may recover internally; only replace the main view when it exits.
                if (args.ProcessFailedKind is CoreWebView2ProcessFailedKind.BrowserProcessExited
                    or CoreWebView2ProcessFailedKind.RenderProcessExited
                    or CoreWebView2ProcessFailedKind.RenderProcessUnresponsive)
                {
                    _browserFaulted = true;
                    ShowPanel("Let’s reconnect.", "The game view stopped responding. Reopen the game to return to its start page.");
                    StatusText.Text = "Game view interrupted";
                }
            };
            core.ContainsFullScreenElementChanged += (_, _) =>
            {
                RunBrowserAction((_, liveCore) =>
                {
                    if (liveCore != core) return;
                    if (core.ContainsFullScreenElement && !_fullScreen)
                    {
                        _documentFullscreen = true;
                        SetFullscreen(true);
                    }
                    else if (!core.ContainsFullScreenElement && _documentFullscreen)
                    {
                        _documentFullscreen = false;
                        SetFullscreen(false);
                    }
                });
            };
            core.Navigate(_endpoint.HomeUri.AbsoluteUri);
            UpdateNavigationButtons();
        }
        catch (WebView2RuntimeNotFoundException)
        {
            _browserFaulted = true;
            ShowPanel("One quick setup step.", "Install Microsoft Edge WebView2 Runtime, then choose Reopen game. This provides the engine your game runs on.", runtime: true);
            StatusText.Text = "WebView2 Runtime is required";
        }
        catch (Exception ex)
        {
            if (_closing) return;
            App.Log(ex);
            _browserFaulted = true;
            ShowPanel("Couldn’t start the game view.", "Try Reopen game. If this continues, update Microsoft Edge WebView2 Runtime and check that your Windows account can save local application data.", runtime: true);
            StatusText.Text = "Client startup interrupted";
        }
        finally
        {
            _initializing = false;
            if (!_closing)
            {
                OptionsButton.IsEnabled = true;
                RecoveryOptionsButton.IsEnabled = true;
                RetryButton.IsEnabled = true;
                UpdateNavigationButtons();
            }
        }
    }

    private void NavigationStarting(object? sender, CoreWebView2NavigationStartingEventArgs e)
    {
        e.Cancel = true;
        RunBrowserAction((browser, core) =>
        {
            if (sender != core) return;
            var current = core.Source;
            // Check redirects as well as direct links; internal/file URLs stay blocked.
            if (!_endpoint.IsAllowed(e.Uri))
            {
                StatusText.Text = "That link is outside this game. Server changes belong in Options.";
                if (!_hasPage)
                    ShowPanel("Check the game address.", "This server redirected outside the configured game folder. Open Options and enter the game’s final base address, including the correct HTTP or HTTPS scheme.");
                return;
            }
            if (e.NavigationKind == CoreWebView2NavigationKind.BackOrForward && _endpoint.IsHome(current))
            {
                StatusText.Text = "You’re at the game’s start page.";
                return;
            }
            e.Cancel = false;
            _activeNavigation = e.NavigationId;
            StatusText.Text = "Loading game…";
            ReloadButton.IsEnabled = false;
        });
    }

    private void NavigationCompleted(object? sender, CoreWebView2NavigationCompletedEventArgs e)
    {
        var browser = _browser;
        if (_closing || browser?.CoreWebView2 is not { } core || sender != core || e.NavigationId != _activeNavigation) return;
        if (e.IsSuccess)
        {
            _hasPage = true;
            _browserFaulted = false;
            WelcomePanel.Visibility = Visibility.Collapsed;
            browser.Visibility = Visibility.Visible;
            StatusText.Text = e.HttpStatusCode >= 400 ? $"Server returned HTTP {e.HttpStatusCode}" : "Ready to play";
            UpdatePageTitle();
            browser.Focus();
            RunBrowserAction((view, liveCore) =>
            {
                if (_endpoint.IsHome(liveCore.Source)) _ = ResetHomeHistoryAsync(liveCore);
            });
        }
        else if (e.WebErrorStatus != CoreWebView2WebErrorStatus.OperationCanceled)
        {
            ShowPanel("Your game is a little out of reach.",
                "Make sure the game server is running and this PC can reach it. For the default local server, start Apache and the game database. Reopen game returns to the start page; use Options to connect to another host.");
            StatusText.Text = "Connection unavailable · " + e.WebErrorStatus;
        }
        UpdateNavigationButtons();
    }

    private void SourceChanged(object? sender, CoreWebView2SourceChangedEventArgs e)
    {
        RunBrowserAction((browser, core) =>
        {
            if (sender != core) return;
            // Covers same-document history changes, which may skip NavigationStarting.
            if (!_endpoint.IsAllowed(core.Source))
            {
                browser.Visibility = Visibility.Hidden;
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    if (IsCurrent(core)) RunBrowserAction((_, liveCore) => liveCore.Navigate(_endpoint.HomeUri.AbsoluteUri));
                }));
            }
            else if (!e.IsNewDocument && _endpoint.IsHome(core.Source))
                _ = ResetHomeHistoryAsync(core);
            UpdateNavigationButtons();
        });
    }

    private void NewWindowRequested(object? sender, CoreWebView2NewWindowRequestedEventArgs e)
    {
        e.Handled = true;
        if (_closing || sender is not CoreWebView2 origin || !IsCurrent(origin)) return;
        if (!_endpoint.IsAllowed(e.Uri))
        {
            StatusText.Text = "External pages stay outside this game client.";
            return;
        }
        var uri = e.Uri;
        // Route permitted target=_blank links into this single game view after the callback returns.
        Dispatcher.BeginInvoke(new Action(() =>
        {
            if (IsCurrent(origin)) RunBrowserAction((_, core) => core.Navigate(uri));
        }));
    }

    private bool IsCurrent(CoreWebView2 core) => !_closing && _browser?.CoreWebView2 == core;

    private async Task ResetHomeHistoryAsync(CoreWebView2 core)
    {
        if (!IsCurrent(core) || _browserFaulted || _historyResetPending) return;
        _historyResetPending = true;
        try
        {
            // Remove entries before this landing page without reloading it or replaying any POST.
            await core.CallDevToolsProtocolMethodAsync("Page.resetNavigationHistory", "{}");
        }
        catch (Exception ex) when (ex is COMException or InvalidOperationException)
        {
            App.Log(ex); // The explicit home/back guard remains in force if the runtime rejects CDP.
        }
        finally
        {
            if (IsCurrent(core))
            {
                _historyResetPending = false;
                UpdateNavigationButtons();
            }
        }
    }

    private void RunBrowserAction(Action<WebView2, CoreWebView2> action)
    {
        if (_closing || _browserFaulted || _browser?.CoreWebView2 is not { } core) return;
        try { action(_browser, core); }
        catch (Exception ex) when (ex is COMException or InvalidOperationException)
        {
            App.Log(ex);
            _browserFaulted = true;
            ShowPanel("Let’s reconnect.", "The game view was interrupted. Reopen the game to continue.");
            StatusText.Text = "Game view interrupted";
        }
    }

    private void UpdateNavigationButtons()
    {
        var core = _browser?.CoreWebView2;
        var ready = core != null && !_initializing && !_browserFaulted;
        HomeButton.IsEnabled = ready;
        ReloadButton.IsEnabled = ready && _hasPage;
        BackButton.IsEnabled = false;
        if (ready && _hasPage && !_historyResetPending)
            RunBrowserAction((_, liveCore) => BackButton.IsEnabled = liveCore.CanGoBack && !_endpoint.IsHome(liveCore.Source));
    }

    private void UpdatePageTitle()
    {
        RunBrowserAction((_, core) =>
        {
            var title = core.DocumentTitle;
            PageTitle.Text = string.IsNullOrWhiteSpace(title) ? "Your adventure awaits" : title;
        });
    }

    private void ShowPanel(string title, string message, bool loading = false, bool runtime = false)
    {
        if (_closing) return;
        if (_browser != null) _browser.Visibility = Visibility.Hidden;
        WelcomePanel.Visibility = Visibility.Visible;
        WelcomeTitle.Text = title;
        WelcomeMessage.Text = message;
        StartupProgress.Visibility = loading ? Visibility.Visible : Visibility.Collapsed;
        RetryButton.Visibility = loading ? Visibility.Collapsed : Visibility.Visible;
        RuntimeButton.Visibility = runtime ? Visibility.Visible : Visibility.Collapsed;
        RecoveryOptionsButton.Visibility = loading ? Visibility.Collapsed : Visibility.Visible;
        UpdateNavigationButtons();
    }

    private void Back_Click(object sender, RoutedEventArgs e) => GoBack();
    private void GoBack()
    {
        RunBrowserAction((_, core) =>
        {
            if (!_historyResetPending && core.CanGoBack && !_endpoint.IsHome(core.Source)) core.GoBack();
        });
    }
    private void Home_Click(object sender, RoutedEventArgs e) => GoHome();
    private void GoHome()
    {
        RunBrowserAction((_, core) => core.Navigate(_endpoint.HomeUri.AbsoluteUri));
    }
    private void Reload_Click(object sender, RoutedEventArgs e) => RefreshPage();
    private void RefreshPage()
    {
        RunBrowserAction((_, core) => { if (_hasPage) core.Reload(); });
    }

    private async void Retry_Click(object sender, RoutedEventArgs e)
    {
        if (_initializing) return;
        if (_browserFaulted || _browser?.CoreWebView2 == null) await InitializeBrowserAsync();
        else
        {
            ShowPanel("Welcome back, Trainer.", "Reconnecting to your game…", loading: true);
            GoHome();
        }
    }

    private void Mute_Click(object sender, RoutedEventArgs e)
    {
        _settings.IsMuted = !_settings.IsMuted;
        RunBrowserAction((_, core) => core.IsMuted = _settings.IsMuted);
        UpdateSoundButton();
        SaveSettings();
    }

    private void UpdateSoundButton()
    {
        MuteButton.Content = _settings.IsMuted ? "Sound muted" : "Sound on";
        MuteButton.ToolTip = _settings.IsMuted ? "Unmute client audio" : "Mute client audio";
    }

    private async void Options_Click(object sender, RoutedEventArgs e)
    {
        if (_initializing) return;
        var dialog = new SettingsWindow(_settings) { Owner = this, Icon = Icon };
        if (dialog.ShowDialog() != true || dialog.SelectedEndpoint == null) return;
        var endpoint = dialog.SelectedEndpoint;
        var changed = endpoint.HomeUri != _endpoint.HomeUri;
        _settings.ServerAddress = endpoint.HomeUri.AbsoluteUri;
        _settings.ZoomFactor = dialog.SelectedZoom;
        _settings.IsMuted = dialog.SelectedMuted;
        _endpoint = endpoint;
        UpdateSoundButton();
        SaveSettings();
        if (changed || _browserFaulted) await InitializeBrowserAsync();
        else RunBrowserAction((browser, core) =>
        {
            core.IsMuted = _settings.IsMuted;
            browser.ZoomFactor = _settings.ZoomFactor;
            browser.Focus();
        });
    }

    private void SaveSettings()
    {
        try { _store.Save(_settings); }
        catch (Exception ex)
        {
            App.Log(ex);
            if (!_closing) MessageBox.Show(this,
                "Your choice applies for this session, but could not be saved. Check free disk space and access to your local application data folder.",
                "Settings could not be saved", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private void Runtime_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            Process.Start(new ProcessStartInfo("https://developer.microsoft.com/microsoft-edge/webview2/#download") { UseShellExecute = true });
        }
        catch (Exception ex)
        {
            App.Log(ex);
            MessageBox.Show(this, "Open Microsoft’s WebView2 download page in your browser and install the Evergreen Runtime.", "Install WebView2");
        }
    }

    private void Window_PreviewKeyDown(object sender, KeyEventArgs e)
    {
        var key = e.Key == Key.System ? e.SystemKey : e.Key;
        var alt = (Keyboard.Modifiers & ModifierKeys.Alt) != 0;
        var ctrl = (Keyboard.Modifiers & ModifierKeys.Control) != 0;
        Action? action = null;
        if (key == Key.F11 || (alt && key == Key.Enter)) action = () => SetFullscreen(!_fullScreen);
        else if (key == Key.Escape && _fullScreen) action = () => SetFullscreen(false);
        else if (key == Key.F5 || (ctrl && key == Key.R)) action = RefreshPage;
        else if (key == Key.BrowserBack || (alt && key == Key.Left)) action = GoBack;
        else if (alt && key == Key.Home) action = GoHome;
        else if (key == Key.BrowserForward || (alt && key == Key.Right) || key == Key.F12 ||
                 (ctrl && key is Key.L or Key.O or Key.N or Key.T or Key.P or Key.U)) action = () => { };
        if (action == null) return; // Preserve game controls, text editing, and Escape when windowed.
        e.Handled = true;
        // WebView2 forwards accelerator callbacks synchronously. Defer native/COM calls until they return.
        if (!e.IsRepeat) Dispatcher.BeginInvoke(action, DispatcherPriority.Normal);
    }

    private void Fullscreen_Click(object sender, RoutedEventArgs e) => SetFullscreen(!_fullScreen);
    private void SetFullscreen(bool value)
    {
        if (_fullScreen == value) return;
        _fullScreen = value;
        if (value)
        {
            _beforeFullscreen = WindowState == WindowState.Normal ? new Rect(Left, Top, Width, Height) : RestoreBounds;
            _stateBeforeFullscreen = WindowState;
            _normalChrome = WindowChrome.GetWindowChrome(this);
            WindowState = WindowState.Normal;
            WindowChrome.SetWindowChrome(this, null);
            ResizeMode = ResizeMode.NoResize;
            TitleBar.Visibility = Visibility.Collapsed;
            Toolbar.Visibility = Visibility.Collapsed;
            Footer.Visibility = Visibility.Collapsed;
            OuterBorder.BorderThickness = new Thickness(0);
            NativeWindow.SizeToMonitor(new WindowInteropHelper(this).Handle);
        }
        else
        {
            _documentFullscreen = false;
            WindowState = WindowState.Normal;
            ResizeMode = ResizeMode.CanResize;
            WindowChrome.SetWindowChrome(this, _normalChrome);
            TitleBar.Visibility = Visibility.Visible;
            Toolbar.Visibility = Visibility.Visible;
            Footer.Visibility = Visibility.Visible;
            OuterBorder.BorderThickness = new Thickness(1);
            Left = _beforeFullscreen.Left; Top = _beforeFullscreen.Top;
            Width = _beforeFullscreen.Width; Height = _beforeFullscreen.Height;
            WindowState = _stateBeforeFullscreen == WindowState.Maximized ? WindowState.Maximized : WindowState.Normal;
            RunBrowserAction((browser, core) =>
            {
                if (core.ContainsFullScreenElement) _ = ExitDocumentFullscreenAsync(core);
            });
        }
        _browser?.Focus();
    }

    private static async Task ExitDocumentFullscreenAsync(CoreWebView2 core)
    {
        try { await core.ExecuteScriptAsync("if(document.fullscreenElement) document.exitFullscreen().catch(()=>{});"); }
        catch (Exception ex) { App.Log(ex); }
    }

    private void Minimize_Click(object sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;
    private void Maximize_Click(object sender, RoutedEventArgs e) => WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
    private void Close_Click(object sender, RoutedEventArgs e) => Close();
    private void Window_StateChanged(object? sender, EventArgs e)
    {
        if (MaximizeButton == null) return;
        MaximizeButton.Content = WindowState == WindowState.Maximized ? "\uE923" : "\uE922";
        MaximizeButton.ToolTip = WindowState == WindowState.Maximized ? "Restore" : "Maximize";
    }
    private void Window_SourceInitialized(object? sender, EventArgs e)
    {
        _windowSource = HwndSource.FromHwnd(new WindowInteropHelper(this).Handle);
        _windowSource?.AddHook(WindowMessage);
    }
    private IntPtr WindowMessage(IntPtr hwnd, int message, IntPtr wParam, IntPtr lParam, ref bool handled)
    {
        if (message == 0x0024)
        {
            var dpi = VisualTreeHelper.GetDpi(this);
            handled = NativeWindow.AdjustMaximizedBounds(hwnd, lParam, _fullScreen,
                (int)Math.Ceiling(MinWidth * dpi.DpiScaleX), (int)Math.Ceiling(MinHeight * dpi.DpiScaleY));
        }
        return IntPtr.Zero;
    }
    private void Window_Closing(object? sender, CancelEventArgs e)
    {
        _closing = true;
        ++_browserGeneration;
        var bounds = _fullScreen ? _beforeFullscreen : WindowState == WindowState.Normal ? new Rect(Left, Top, Width, Height) : RestoreBounds;
        if (!bounds.IsEmpty && bounds.Width > 0 && bounds.Height > 0)
        {
            _settings.WindowWidth = bounds.Width;
            _settings.WindowHeight = bounds.Height;
        }
        _settings.IsMaximized = (_fullScreen ? _stateBeforeFullscreen : WindowState) == WindowState.Maximized;
        SaveSettings();
        _windowSource?.RemoveHook(WindowMessage);
        DisposeBrowser();
    }
    private void DisposeBrowser()
    {
        var browser = _browser;
        _browser = null;
        BrowserHost.Children.Clear();
        try { browser?.Dispose(); }
        catch (Exception ex) when (ex is COMException or InvalidOperationException) { App.Log(ex); }
    }
}
